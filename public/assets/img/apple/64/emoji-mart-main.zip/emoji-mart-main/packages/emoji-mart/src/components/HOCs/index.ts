export { default as PureInlineComponent } from './PureInlineComponent'
