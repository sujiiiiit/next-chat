import NativeSupport from '../native-support'

describe('NativeSupport', () => {
  test.skip('', () => {})
})
