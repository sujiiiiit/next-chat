import FrequentlyUsed from '../frequently-used'

describe('FrequentlyUsed', () => {
  test.skip('', () => {})
})
