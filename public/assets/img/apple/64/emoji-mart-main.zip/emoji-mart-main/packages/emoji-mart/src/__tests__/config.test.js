import { init } from '../config'

describe('init', () => {
  test.skip('', () => {})
})
