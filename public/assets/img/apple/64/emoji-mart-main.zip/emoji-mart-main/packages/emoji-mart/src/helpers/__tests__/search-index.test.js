import SearchIndex from '../search-index'

describe('SearchIndex', () => {
  test.skip('', () => {})
})
