# `@emoji-mart/data`

This package contains the data used by [EmojiMart](https://missiveapp.com/open/emoji-mart).
