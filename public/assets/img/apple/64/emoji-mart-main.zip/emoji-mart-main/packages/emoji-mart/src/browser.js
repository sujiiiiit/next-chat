import * as EmojiMart from './index'
window.EmojiMart = EmojiMart
