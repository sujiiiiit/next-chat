import Store from '../store'

describe('Store', () => {
  test.skip('', () => {})
})
